# Creating Dynamic Charts using FusionCharts and Firebase

[Demo](https://sikrigagan.github.io/Firebase-Charts/index.html)
