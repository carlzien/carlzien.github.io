// Initialize Firebase
var config = {
    apiKey: "AIzaSyCUGTrY5OD1uBupNIHvCRxEO1NKYVlPtDM",
    authDomain: "fusioncharts-demo.firebaseapp.com",
    databaseURL: "https://fusioncharts-demo.firebaseio.com",
    projectId: "fusioncharts-demo",
    storageBucket: "fusioncharts-demo.appspot.com",
    messagingSenderId: "728123238984"
};
firebase.initializeApp(config);
